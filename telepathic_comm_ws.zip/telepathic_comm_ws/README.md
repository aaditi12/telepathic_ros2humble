# ROS 2 Humble AI Telepathic Communication Simulation Framework
### Digital-Twin Robot Swarm Controlled by Simulated Brain Intent

This workspace implements a simulation framework for **"telepathic"
communication**: a single simulated human "thought" (EEG-derived intent) is
decoded by an AI model and broadcast, with no explicit per-robot addressing,
to every digital twin in a robot swarm simultaneously — the defining
property of a telepathic/broadcast link versus normal point-to-point
communication (e.g. a teleop node driving one robot).

## 1. Architecture

```
 ┌──────────────────────┐        /eeg/raw (EEGSignal)
 │  eeg_simulator_node   │ ───────────────────────────────┐
 │ (digital twin of the  │                                 │
 │  human operator's     │                                 ▼
 │  brain activity)      │                     ┌───────────────────────┐
 └──────────────────────┘                     │  intent_decoder_node   │
                                                │  (AI classifier:      │
                                                │  band-power features  │
                                                │  + nearest-centroid   │
                                                │  model)                │
                                                └───────────┬───────────┘
                                                             │ /telepathy/intent (Intent)
                                                             ▼
                                                ┌────────────────────────────┐
                                                │ telepathic_broadcaster_node │
                                                │ (majority-vote smoothing,   │
                                                │  confidence gating)         │
                                                └───────────┬────────────────┘
                                                             │ /telepathy/broadcast (Intent)
                                    ┌────────────────────────┼────────────────────────┐
                                    ▼                        ▼                        ▼
                          ┌──────────────────┐   ┌──────────────────┐   ┌──────────────────┐
                          │ robot_1 (Gazebo)  │   │ robot_2 (Gazebo)  │   │ robot_3 (Gazebo)  │
                          │ telepathy_receiver│   │ telepathy_receiver│   │ telepathy_receiver│
                          │ -> cmd_vel        │   │ -> cmd_vel        │   │ -> cmd_vel        │
                          └──────────────────┘   └──────────────────┘   └──────────────────┘
```

Every robot subscribes to the *same* `/telepathy/broadcast` topic. There is
no robot-specific channel — that one-to-many, unaddressed fan-out is what
this framework is modeling as "telepathy," as opposed to conventional
teleoperation (one operator -> one robot, explicitly addressed).

## 2. Packages

| Package              | Type          | Purpose                                                             |
|----------------------|---------------|----------------------------------------------------------------------|
| `telepathy_msgs`     | ament_cmake   | Custom interfaces: `EEGSignal.msg`, `Intent.msg`                     |
| `telepathy_core`     | ament_python  | `eeg_simulator_node`, `intent_decoder_node`, `telepathic_broadcaster_node`, shared signal/classifier utilities |
| `telepathy_receiver` | ament_python  | `receiver_node` — runs once per robot, converts broadcast intent to `cmd_vel` |
| `telepathy_bringup`  | ament_cmake   | Launch files, robot URDF/xacro, Gazebo world, RViz config            |

## 3. How the "AI" decoding works

1. **Simulated EEG** (`signal_utils.generate_window`): each of the 5 intents
   (`FORWARD`, `BACKWARD`, `LEFT`, `RIGHT`, `STOP`) is given a distinct
   spectral/spatial signature — dominant frequency band (theta/alpha/beta)
   and per-channel gain pattern (e.g. left/right hemisphere asymmetry for
   `LEFT` vs `RIGHT`) — plus additive noise, mimicking how real motor-imagery
   BCIs distinguish intents via band power and hemispheric asymmetry.
2. **Feature extraction** (`signal_utils.extract_features`): per-channel
   theta/alpha/beta band power (via FFT) plus an alpha asymmetry index.
3. **Classification** (`IntentClassifier`): a nearest-centroid model,
   calibrated at node startup from bootstrapped synthetic training windows
   (the same generator, used as a stand-in "calibration session"). This is
   swappable — replace `IntentClassifier.classify()` with a trained
   scikit-learn/PyTorch model without touching any other node.
4. **Stabilization** (`telepathic_broadcaster_node`): majority-vote
   smoothing over a sliding window of decoded intents plus a confidence
   threshold, so the swarm doesn't jitter between commands on every noisy
   frame — analogous to attention/thought-stabilization filtering in real
   BCI pipelines.

Validated standalone (no ROS needed) in this repo's development: 200
held-out synthetic windows decoded, see `intent_classifier.py` +
`signal_utils.py` — the classifier reliably separates all 5 intents given
the simulator's signal design.

## 4. Build

```bash
# Inside your ROS 2 Humble environment (Ubuntu 22.04)
sudo apt update
sudo apt install -y ros-humble-gazebo-ros-pkgs ros-humble-xacro \
                     ros-humble-robot-state-publisher python3-numpy

cd telepathic_comm_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

## 5. Run

### Quick check: AI pipeline only (no Gazebo)
```bash
ros2 launch telepathy_bringup pipeline_only.launch.py
```
Watch the terminal: the simulated subject switches intent every ~4s, the
decoder logs running accuracy every 10 windows, and the broadcaster logs
`>>> TELEPATHIC BROADCAST: "..."` whenever the stabilized intent changes.

### Full digital twin swarm in Gazebo
```bash
ros2 launch telepathy_bringup digital_twin_swarm.launch.py num_robots:=3
```
This starts Gazebo with the `telepathy_arena` world, spawns 3 independent
robot digital twins (`robot_1`, `robot_2`, `robot_3`), and starts the full
telepathic pipeline. All three robots should move in lockstep whenever a
new intent is broadcast, since they're all listening to the same
unaddressed `/telepathy/broadcast` topic.

Inspect topics live:
```bash
ros2 topic echo /eeg/raw --field true_intent_label
ros2 topic echo /telepathy/intent
ros2 topic echo /telepathy/broadcast
ros2 topic echo /robot_1/cmd_vel
```

Visualize in RViz:
```bash
rviz2 -d src/telepathy_bringup/rviz/swarm.rviz
```

## 6. Tunable parameters

| Node                          | Parameter                        | Default | Effect                                    |
|--------------------------------|-----------------------------------|---------|--------------------------------------------|
| `eeg_simulator_node`           | `intent_switch_period_sec`        | 4.0     | How often the simulated subject changes intent |
| `eeg_simulator_node`           | `noise_std`                       | 0.3     | Simulated EEG noise level (higher = harder to decode) |
| `intent_decoder_node`          | `calibration_windows_per_class`   | 40      | Synthetic training samples per class for the classifier |
| `telepathic_broadcaster_node`  | `smoothing_window`                | 5       | Majority-vote window size (higher = more stable, more latency) |
| `telepathic_broadcaster_node`  | `min_confidence`                  | 0.3     | Minimum decoder confidence to count a frame at all |
| `telepathy_receiver` (per robot)| `min_confidence`                 | 0.3     | Minimum broadcast confidence to actuate    |

## 7. Extending this framework

- **Real EEG hardware**: replace `eeg_simulator_node` with a driver
  publishing real `EEGSignal` messages (e.g. from an OpenBCI/Muse SDK
  bridge); everything downstream is unchanged.
- **Trained deep model**: swap `IntentClassifier` for a CNN/LSTM trained on
  a real motor-imagery dataset (e.g. BCI Competition IV); keep the same
  `classify(feature_vector) -> (label, confidence)` interface.
- **Selective/multi-channel telepathy**: extend the broadcaster to publish
  per-group topics (e.g. `/telepathy/broadcast/group_a`) so different
  operators or thought-channels can control different sub-swarms.
- **Humanoid twin**: swap `swarm_bot.urdf.xacro` and the receiver's
  intent-to-actuation mapping for a humanoid URDF (e.g. map `GRASP` to a
  gripper/hand joint trajectory instead of `cmd_vel`).
