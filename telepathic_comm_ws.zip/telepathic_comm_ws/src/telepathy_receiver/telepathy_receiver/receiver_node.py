"""
receiver_node.py
------------------
Runs on every robot digital twin in the swarm. Subscribes to the single
shared /telepathy/broadcast topic (no per-robot addressing -- that's the
"telepathic" part: every twin hears the same thought at the same time)
and converts the received intent directly into actuation (cmd_vel) for
that robot.

Launched once per robot with a unique node name / namespace so that
cmd_vel goes to the right robot in the Gazebo digital twin world.
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

from telepathy_msgs.msg import Intent

# Simple mapping from decoded intent -> velocity command.
_INTENT_TO_TWIST = {
    'FORWARD': (0.4, 0.0),
    'BACKWARD': (-0.4, 0.0),
    'LEFT': (0.0, 0.8),
    'RIGHT': (0.0, -0.8),
    'STOP': (0.0, 0.0),
}


class TelepathyReceiverNode(Node):
    def __init__(self):
        super().__init__('telepathy_receiver_node')

        self.declare_parameter('robot_id', 'robot_1')
        self.declare_parameter('min_confidence', 0.3)
        self.declare_parameter('cmd_vel_topic', 'cmd_vel')

        self.robot_id = self.get_parameter('robot_id').value
        self.min_confidence = float(self.get_parameter('min_confidence').value)
        cmd_vel_topic = self.get_parameter('cmd_vel_topic').value

        self.subscription = self.create_subscription(
            Intent, '/telepathy/broadcast', self._on_broadcast, 10)
        self.cmd_pub = self.create_publisher(Twist, cmd_vel_topic, 10)

        self.get_logger().info(
            f'Digital twin "{self.robot_id}" is telepathically linked and listening.')

    def _on_broadcast(self, msg: Intent):
        if msg.confidence < self.min_confidence:
            return

        linear, angular = _INTENT_TO_TWIST.get(msg.label, (0.0, 0.0))

        twist = Twist()
        twist.linear.x = linear
        twist.angular.z = angular
        self.cmd_pub.publish(twist)

        self.get_logger().info(
            f'[{self.robot_id}] received thought "{msg.label}" -> '
            f'v={linear:.2f} m/s, w={angular:.2f} rad/s')


def main(args=None):
    rclpy.init(args=args)
    node = TelepathyReceiverNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
