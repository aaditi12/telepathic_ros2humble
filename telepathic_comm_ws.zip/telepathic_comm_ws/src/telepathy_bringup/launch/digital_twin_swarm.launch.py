"""
digital_twin_swarm.launch.py
------------------------------
Brings up the full AI Telepathic Communication Simulation Framework:

  1. Gazebo with the telepathy_arena world.
  2. N robot digital twins (namespaced robot_1..robot_N), each with
     robot_state_publisher + a spawned URDF + a telepathy receiver node.
  3. The telepathic pipeline: EEG simulator -> intent decoder -> broadcaster.

Usage:
  ros2 launch telepathy_bringup digital_twin_swarm.launch.py num_robots:=3
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _spawn_robots(context, *args, **kwargs):
    num_robots = int(LaunchConfiguration('num_robots').perform(context))
    bringup_share = get_package_share_directory('telepathy_bringup')
    xacro_path = os.path.join(bringup_share, 'urdf', 'swarm_bot.urdf.xacro')

    actions = []
    positions = [(0.0, 0.0), (1.5, 0.0), (-1.5, 0.0), (0.0, 1.5), (0.0, -1.5)]

    for i in range(num_robots):
        robot_name = f'robot_{i + 1}'
        x, y = positions[i % len(positions)]

        robot_desc_cmd = [
            'xacro ', xacro_path,
            ' robot_name:=', robot_name,
        ]

        actions.append(Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            namespace=robot_name,
            output='screen',
            parameters=[{
                'robot_description': _xacro_to_string(xacro_path, robot_name),
                'frame_prefix': f'{robot_name}/',
            }],
        ))

        actions.append(Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            name=f'spawn_{robot_name}',
            output='screen',
            arguments=[
                '-topic', f'/{robot_name}/robot_description',
                '-entity', robot_name,
                '-robot_namespace', robot_name,
                '-x', str(x), '-y', str(y), '-z', '0.05',
            ],
        ))

        actions.append(Node(
            package='telepathy_receiver',
            executable='receiver_node',
            name='telepathy_receiver_node',
            namespace=robot_name,
            output='screen',
            parameters=[{
                'robot_id': robot_name,
                'min_confidence': 0.3,
                'cmd_vel_topic': 'cmd_vel',
            }],
        ))

    return actions


def _xacro_to_string(xacro_path, robot_name):
    import xacro
    doc = xacro.process_file(xacro_path, mappings={'robot_name': robot_name})
    return doc.toxml()


def generate_launch_description():
    bringup_share = get_package_share_directory('telepathy_bringup')
    world_path = os.path.join(bringup_share, 'worlds', 'telepathy_arena.world')

    gazebo_ros_share = get_package_share_directory('gazebo_ros')
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_share, 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={'world': world_path}.items(),
    )

    num_robots_arg = DeclareLaunchArgument(
        'num_robots', default_value='3',
        description='Number of robot digital twins in the telepathic swarm')

    eeg_simulator = Node(
        package='telepathy_core',
        executable='eeg_simulator_node',
        name='eeg_simulator_node',
        output='screen',
    )

    intent_decoder = Node(
        package='telepathy_core',
        executable='intent_decoder_node',
        name='intent_decoder_node',
        output='screen',
    )

    telepathic_broadcaster = Node(
        package='telepathy_core',
        executable='telepathic_broadcaster_node',
        name='telepathic_broadcaster_node',
        output='screen',
    )

    return LaunchDescription([
        num_robots_arg,
        gazebo_launch,
        OpaqueFunction(function=_spawn_robots),
        eeg_simulator,
        intent_decoder,
        telepathic_broadcaster,
    ])
