"""
pipeline_only.launch.py
--------------------------
Runs just the telepathic AI pipeline (EEG simulator -> intent decoder ->
broadcaster) with no Gazebo/robots. Useful for quickly checking the
decoding accuracy and broadcast behavior in the terminal, e.g. while
iterating on the classifier, before spinning up the full digital twin
simulation.

Usage:
  ros2 launch telepathy_bringup pipeline_only.launch.py
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='telepathy_core',
            executable='eeg_simulator_node',
            name='eeg_simulator_node',
            output='screen',
        ),
        Node(
            package='telepathy_core',
            executable='intent_decoder_node',
            name='intent_decoder_node',
            output='screen',
        ),
        Node(
            package='telepathy_core',
            executable='telepathic_broadcaster_node',
            name='telepathic_broadcaster_node',
            output='screen',
        ),
    ])
