from setuptools import find_packages, setup

package_name = 'telepathy_core'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools', 'numpy'],
    zip_safe=True,
    maintainer='maa',
    maintainer_email='maa@example.com',
    description='AI Telepathic Communication Simulation Framework - core nodes',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'eeg_simulator_node = telepathy_core.eeg_simulator_node:main',
            'intent_decoder_node = telepathy_core.intent_decoder_node:main',
            'telepathic_broadcaster_node = telepathy_core.telepathic_broadcaster_node:main',
        ],
    },
)
