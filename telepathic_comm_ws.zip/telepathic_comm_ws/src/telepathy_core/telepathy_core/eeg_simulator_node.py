"""
eeg_simulator_node.py
----------------------
Simulates a human "subject" wearing an EEG headset, thinking one of a
fixed set of intents. Publishes rolling EEG windows on /eeg/raw.

The current intent changes periodically (simulating a person deciding
what to make the swarm do next). This node is the digital twin of the
*human operator's brain*, not of a robot.
"""

import random

import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Header

from telepathy_core.signal_utils import INTENT_LABELS, generate_window
from telepathy_msgs.msg import EEGSignal


class EEGSimulatorNode(Node):
    def __init__(self):
        super().__init__('eeg_simulator_node')

        self.declare_parameter('subject_id', 'operator_1')
        self.declare_parameter('sample_rate', 128.0)
        self.declare_parameter('n_channels', 4)
        self.declare_parameter('n_samples', 128)
        self.declare_parameter('window_period_sec', 1.0)
        self.declare_parameter('intent_switch_period_sec', 4.0)
        self.declare_parameter('noise_std', 0.3)

        self.subject_id = self.get_parameter('subject_id').value
        self.sample_rate = float(self.get_parameter('sample_rate').value)
        self.n_channels = int(self.get_parameter('n_channels').value)
        self.n_samples = int(self.get_parameter('n_samples').value)
        self.window_period = float(self.get_parameter('window_period_sec').value)
        self.intent_switch_period = float(self.get_parameter('intent_switch_period_sec').value)
        self.noise_std = float(self.get_parameter('noise_std').value)

        self.publisher_ = self.create_publisher(EEGSignal, '/eeg/raw', 10)

        self._rng = np.random.default_rng()
        self._current_intent = random.choice(INTENT_LABELS)
        self.get_logger().info(f'Subject "{self.subject_id}" is now thinking: {self._current_intent}')

        self.create_timer(self.window_period, self._publish_window)
        self.create_timer(self.intent_switch_period, self._switch_intent)

    def _switch_intent(self):
        choices = [lbl for lbl in INTENT_LABELS if lbl != self._current_intent]
        self._current_intent = random.choice(choices)
        self.get_logger().info(f'Subject "{self.subject_id}" is now thinking: {self._current_intent}')

    def _publish_window(self):
        window = generate_window(
            self._current_intent,
            sample_rate=self.sample_rate,
            n_channels=self.n_channels,
            n_samples=self.n_samples,
            noise_std=self.noise_std,
            rng=self._rng,
        )

        msg = EEGSignal()
        msg.header = Header()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'eeg_headset'
        msg.subject_id = self.subject_id
        msg.sample_rate = self.sample_rate
        msg.n_channels = self.n_channels
        msg.n_samples = self.n_samples
        msg.samples = window.flatten().tolist()
        msg.true_intent_label = self._current_intent

        self.publisher_.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = EEGSimulatorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
