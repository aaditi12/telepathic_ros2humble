"""
intent_decoder_node.py
------------------------
Subscribes to raw simulated EEG windows and runs them through the AI
decoding model (IntentClassifier) to produce a discrete Intent message.
Also tracks online decoding accuracy against the simulator's
ground-truth label (simulation-only diagnostic).
"""

import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Header

from telepathy_core.intent_classifier import IntentClassifier
from telepathy_core.signal_utils import extract_features
from telepathy_msgs.msg import EEGSignal, Intent


class IntentDecoderNode(Node):
    def __init__(self):
        super().__init__('intent_decoder_node')

        self.declare_parameter('calibration_windows_per_class', 40)

        n_cal = int(self.get_parameter('calibration_windows_per_class').value)

        self._classifier = None  # built lazily once we know signal shape
        self._n_total = 0
        self._n_correct = 0
        self._n_cal = n_cal

        self.subscription = self.create_subscription(
            EEGSignal, '/eeg/raw', self._on_eeg, 10)
        self.publisher_ = self.create_publisher(Intent, '/telepathy/intent', 10)

        self.get_logger().info('Intent decoder online, waiting for first EEG window to calibrate model...')

    def _ensure_classifier(self, msg: EEGSignal):
        if self._classifier is None:
            self._classifier = IntentClassifier(
                sample_rate=msg.sample_rate,
                n_channels=msg.n_channels,
                n_samples=msg.n_samples,
                calibration_windows_per_class=self._n_cal,
            )
            self.get_logger().info('AI decoding model calibrated on synthetic training data.')

    def _on_eeg(self, msg: EEGSignal):
        self._ensure_classifier(msg)

        window = np.array(msg.samples, dtype=np.float32).reshape(
            msg.n_channels, msg.n_samples)
        feats = extract_features(window, msg.sample_rate)
        label, confidence = self._classifier.classify(feats)

        self._n_total += 1
        if msg.true_intent_label and label == msg.true_intent_label:
            self._n_correct += 1
        if self._n_total % 10 == 0:
            acc = 100.0 * self._n_correct / self._n_total
            self.get_logger().info(
                f'Decoder running accuracy: {acc:.1f}% over {self._n_total} windows')

        out = Intent()
        out.header = Header()
        out.header.stamp = self.get_clock().now().to_msg()
        out.header.frame_id = 'intent_decoder'
        out.label = label
        out.confidence = float(confidence)
        out.source_id = 'intent_decoder_node'

        self.publisher_.publish(out)


def main(args=None):
    rclpy.init(args=args)
    node = IntentDecoderNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
