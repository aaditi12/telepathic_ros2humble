"""
signal_utils.py
----------------
Shared synthetic-EEG generation used both by the EEG simulator node
(to fabricate the "subject's" brain activity) and by the intent decoder's
calibration routine (to bootstrap a small training set for its classifier).

This is a *simulation* of EEG, not a physiological model: each mental
"intent" is associated with a distinguishing spectral/spatial signature
(dominant band + inter-channel amplitude pattern), which is the same kind
of feature real BCI decoders rely on (band power + hemispheric asymmetry).
"""

import numpy as np

INTENT_LABELS = ["FORWARD", "BACKWARD", "LEFT", "RIGHT", "STOP"]

# Canonical EEG bands (Hz)
BAND_THETA = (4.0, 8.0)
BAND_ALPHA = (8.0, 13.0)
BAND_BETA = (13.0, 30.0)

# Per-intent signal "recipe": (dominant_freq_hz, per_channel_gain, band_name)
# 4 simulated channels ~ (F3-like, F4-like, C3-like, C4-like): left/right x front/central
_RECIPES = {
    "FORWARD": {"freq": 20.0, "gains": [1.0, 1.0, 1.1, 1.1], "band": "beta"},
    "BACKWARD": {"freq": 6.0, "gains": [0.9, 0.9, 0.8, 0.8], "band": "theta"},
    "LEFT": {"freq": 10.0, "gains": [0.4, 1.3, 0.4, 1.2], "band": "alpha"},   # right-hemisphere heavy -> intent LEFT
    "RIGHT": {"freq": 10.0, "gains": [1.3, 0.4, 1.2, 0.4], "band": "alpha"},  # left-hemisphere heavy -> intent RIGHT
    "STOP": {"freq": 2.0, "gains": [0.3, 0.3, 0.3, 0.3], "band": "delta_noise"},
}


def generate_window(label, sample_rate=128.0, n_channels=4, n_samples=128,
                     noise_std=0.25, rng=None):
    """Generate one synthetic multi-channel EEG window for a given intent label.

    Returns an (n_channels, n_samples) float32 numpy array.
    """
    if rng is None:
        rng = np.random.default_rng()
    if label not in _RECIPES:
        raise ValueError(f"Unknown intent label: {label}")

    recipe = _RECIPES[label]
    t = np.arange(n_samples) / sample_rate
    window = np.zeros((n_channels, n_samples), dtype=np.float32)

    for ch in range(n_channels):
        gain = recipe["gains"][ch % len(recipe["gains"])]
        base = gain * np.sin(2 * np.pi * recipe["freq"] * t)
        # small harmonic + 1/f-ish drift to make it look more organic
        harmonic = 0.15 * gain * np.sin(2 * np.pi * (recipe["freq"] * 2.0) * t + 0.3)
        drift = 0.1 * np.sin(2 * np.pi * 0.5 * t)
        noise = rng.normal(0.0, noise_std, size=n_samples)
        window[ch, :] = base + harmonic + drift + noise

    return window.astype(np.float32)


def band_power(signal_1d, sample_rate, band):
    """Compute average FFT power of a 1D signal within a frequency band (Hz)."""
    n = signal_1d.shape[0]
    freqs = np.fft.rfftfreq(n, d=1.0 / sample_rate)
    spectrum = np.abs(np.fft.rfft(signal_1d)) ** 2
    mask = (freqs >= band[0]) & (freqs < band[1])
    if not np.any(mask):
        return 0.0
    return float(np.mean(spectrum[mask]))


def extract_features(window, sample_rate):
    """Extract a compact feature vector from an (n_channels, n_samples) window.

    Features: per-channel theta/alpha/beta band power, plus a left-right
    alpha asymmetry index (channel 0 vs channel 1) which is what
    distinguishes LEFT vs RIGHT intents.
    """
    n_channels = window.shape[0]
    feats = []
    alpha_powers = []
    for ch in range(n_channels):
        theta_p = band_power(window[ch], sample_rate, BAND_THETA)
        alpha_p = band_power(window[ch], sample_rate, BAND_ALPHA)
        beta_p = band_power(window[ch], sample_rate, BAND_BETA)
        feats.extend([theta_p, alpha_p, beta_p])
        alpha_powers.append(alpha_p)

    # hemispheric asymmetry: (ch0 - ch1) / (ch0 + ch1) using alpha power
    ch0, ch1 = alpha_powers[0], alpha_powers[1]
    asymmetry = (ch0 - ch1) / (ch0 + ch1 + 1e-6)
    feats.append(asymmetry)

    return np.array(feats, dtype=np.float32)
