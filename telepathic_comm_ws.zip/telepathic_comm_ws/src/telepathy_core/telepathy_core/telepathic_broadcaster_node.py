"""
telepathic_broadcaster_node.py
--------------------------------
The heart of the "telepathic link": takes the (possibly noisy,
frame-by-frame) decoded intent stream and applies majority-vote
smoothing over a sliding window (simulating attention/thought
stabilization), then broadcasts the stabilized intent on a single
shared topic, /telepathy/broadcast.

Every digital twin in the swarm subscribes to this same topic with no
individual addressing -- one decoded thought instantaneously reaches
every robot at once, which is the "telepathic" (one-to-many, no
explicit point-to-point messaging) property this framework is
simulating.
"""

from collections import Counter, deque

import rclpy
from rclpy.node import Node
from std_msgs.msg import Header

from telepathy_msgs.msg import Intent


class TelepathicBroadcasterNode(Node):
    def __init__(self):
        super().__init__('telepathic_broadcaster_node')

        self.declare_parameter('smoothing_window', 5)
        self.declare_parameter('min_confidence', 0.3)

        self.smoothing_window = int(self.get_parameter('smoothing_window').value)
        self.min_confidence = float(self.get_parameter('min_confidence').value)

        self._recent = deque(maxlen=self.smoothing_window)
        self._last_broadcast_label = None

        self.subscription = self.create_subscription(
            Intent, '/telepathy/intent', self._on_intent, 10)
        self.publisher_ = self.create_publisher(Intent, '/telepathy/broadcast', 10)

        self.get_logger().info(
            f'Telepathic broadcaster online (smoothing_window={self.smoothing_window}, '
            f'min_confidence={self.min_confidence})')

    def _on_intent(self, msg: Intent):
        if msg.confidence < self.min_confidence:
            return  # too uncertain to count this "thought" at all

        self._recent.append(msg.label)
        if len(self._recent) < self.smoothing_window:
            return  # not enough evidence yet to commit to a stable intent

        counts = Counter(self._recent)
        stable_label, votes = counts.most_common(1)[0]
        stable_confidence = votes / len(self._recent)

        if stable_label == self._last_broadcast_label:
            return  # no change -- don't spam the swarm with repeats

        self._last_broadcast_label = stable_label

        out = Intent()
        out.header = Header()
        out.header.stamp = self.get_clock().now().to_msg()
        out.header.frame_id = 'telepathic_link'
        out.label = stable_label
        out.confidence = float(stable_confidence)
        out.source_id = 'telepathic_broadcaster_node'

        self.get_logger().info(
            f'>>> TELEPATHIC BROADCAST: "{stable_label}" (confidence {stable_confidence:.2f}) '
            f'-> all digital twins')
        self.publisher_.publish(out)


def main(args=None):
    rclpy.init(args=args)
    node = TelepathicBroadcasterNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()


