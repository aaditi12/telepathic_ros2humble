"""
intent_classifier.py
---------------------
A lightweight "AI" decoding model for turning EEG feature vectors into
discrete intents. It is a nearest-centroid classifier in standardized
feature space, calibrated on the fly from bootstrapped synthetic training
windows (same generator the EEG simulator node uses). This mirrors how a
real BCI pipeline is trained on a calibration session before online use.

Swappable: replace `IntentClassifier.classify()` with a trained
scikit-learn/PyTorch model without touching any other node.
"""

import numpy as np

from telepathy_core.signal_utils import (
    INTENT_LABELS,
    extract_features,
    generate_window,
)


class IntentClassifier:
    def __init__(self, sample_rate=128.0, n_channels=4, n_samples=128,
                 calibration_windows_per_class=40, seed=42):
        self.sample_rate = sample_rate
        self.n_channels = n_channels
        self.n_samples = n_samples
        self._mean = None
        self._std = None
        self._centroids = {}
        self._calibrate(calibration_windows_per_class, seed)

    def _calibrate(self, n_per_class, seed):
        rng = np.random.default_rng(seed)
        all_feats = []
        labeled_feats = {label: [] for label in INTENT_LABELS}

        for label in INTENT_LABELS:
            for _ in range(n_per_class):
                window = generate_window(
                    label, self.sample_rate, self.n_channels, self.n_samples,
                    noise_std=0.3, rng=rng,
                )
                feats = extract_features(window, self.sample_rate)
                labeled_feats[label].append(feats)
                all_feats.append(feats)

        all_feats = np.stack(all_feats, axis=0)
        self._mean = all_feats.mean(axis=0)
        self._std = all_feats.std(axis=0) + 1e-6

        for label in INTENT_LABELS:
            stacked = np.stack(labeled_feats[label], axis=0)
            standardized = (stacked - self._mean) / self._std
            self._centroids[label] = standardized.mean(axis=0)

    def classify(self, feature_vector):
        """Return (label, confidence[0..1]) for a raw feature vector."""
        z = (feature_vector - self._mean) / self._std
        dists = {
            label: float(np.linalg.norm(z - centroid))
            for label, centroid in self._centroids.items()
        }
        best_label = min(dists, key=dists.get)

        # Convert distances to a soft confidence score via inverse-distance
        # softmax-like normalization.
        inv = {label: 1.0 / (d + 1e-3) for label, d in dists.items()}
        total = sum(inv.values())
        confidence = inv[best_label] / total

        return best_label, confidence
